# Game-Ular-HD

Game ular sederhana menggunakan HTML, CSS, dan JavaScript.

## Fitur
- Kontrol panah keyboard
- Skor otomatis
- Tembus tembok
- Game Over saat menabrak badan sendiri
